'use client'
import React from 'react'
import Link from 'next/link'

export default function Header(){
  return (
    <header className="header">
      <div className="container topbar">
        <div style={{display:'flex',alignItems:'center',gap:16}}>
          <div className="logo"><Link href="/">TRENDOK</Link></div>
          <nav className="nav mega">
            <div className="mega">
              <a href="#">Femei</a>
              <div className="mega-menu">
                <a href="#">Rochii</a><br/>
                <a href="#">Topuri</a><br/>
                <a href="#">Accesorii</a>
              </div>
            </div>
            <a href="#">Bărbați</a>
            <a href="#">Copii</a>
            <a href="#">Accesorii</a>
          </nav>
        </div>

        <div style={{display:'flex',alignItems:'center',gap:12}}>
          <div className="search" style={{maxWidth:420}}>
            <input placeholder="Caută produse..." />
          </div>
          <Link href="/cart"><a className="btn">Coș</a></Link>
        </div>
      </div>
    </header>
  )
}
