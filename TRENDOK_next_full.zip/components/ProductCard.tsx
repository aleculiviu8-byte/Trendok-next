import React from 'react'
import Link from 'next/link'

export default function ProductCard({product}:{product:any}){
  return (
    <div className="card" style={{cursor:'pointer'}}>
      <Link href={`/product/${product.id}`}>
        <a>
          <div className="img" style={{backgroundImage:`url(${product.image})`}}></div>
          <div className="meta">
            <div style={{color:'#6b7280',fontSize:13}}>{product.brand}</div>
            <div style={{fontWeight:600}}>{product.title}</div>
            <div style={{marginTop:8}}>
              <div className="price">{product.price} lei</div>
              <div className="price-old">{product.oldPrice} lei</div>
            </div>
          </div>
        </a>
      </Link>
    </div>
  )
}
