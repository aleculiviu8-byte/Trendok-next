TRENDOK — Next.js 14 Starter (Shein-like full demo)

How to run:
1. Install dependencies:
   npm install

2. Run dev server:
   npm run dev

This project uses the App Router (app/) and includes:
- home page (app/page.tsx)
- product page (app/product/[id]/page.tsx)
- cart page (app/cart/page.tsx)
- API mock: app/api/products/route.ts
- components: Header, ProductCard, Layout
- simple styling in styles/globals.css

Notes:
- Replace placeholder images (picsum) with your assets in /public or external URLs.
- For production, set environment variables and connect a real backend or headless CMS.
