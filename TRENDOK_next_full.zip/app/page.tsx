import React from 'react'
import ProductCard from '../components/ProductCard'

export default async function Home() {
  // fetch products from mock API
  const res = await fetch(`${process.env.NEXT_PUBLIC_SITE_URL || ''}/api/products`);
  const products = await res.json();

  return (
    <div>
      <section className="hero" style={{backgroundImage:`url('https://picsum.photos/id/1011/1400/900')`}}>
        <div className="hero-box">
          <h1 style={{fontSize:36, margin:0}}>Noua Colecție — Primăvară</h1>
          <p style={{color:'#374151'}}>Trenduri fresh, prețuri accesibile.</p>
          <div style={{marginTop:12}}>
            <a className="btn" href="#">Cumpără acum</a>
          </div>
        </div>
      </section>

      <section style={{padding:'32px 0'}}>
        <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:12}}>
          <h2>🔥 Flash Sale</h2>
          <a href="#">Vezi toate ofertele</a>
        </div>

        <div className="grid products-grid">
          {products.slice(0,5).map((p:any) => (
            <ProductCard key={p.id} product={p} />
          ))}
        </div>
      </section>

      <section style={{padding:'16px 0'}}>
        <h3>Recomandate pentru tine</h3>
        <div className="grid products-grid">
          {products.map((p:any) => <ProductCard key={p.id} product={p} />)}
        </div>
      </section>
    </div>
  )
}
