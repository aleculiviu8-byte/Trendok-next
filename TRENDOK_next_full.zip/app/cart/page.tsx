import React from 'react'

export default function CartPage(){
  return (
    <div style={{paddingTop:20}}>
      <h1>Coșul tău</h1>
      <p>Funcționalitate demo — integrăm coș real la cerere.</p>
    </div>
  )
}
