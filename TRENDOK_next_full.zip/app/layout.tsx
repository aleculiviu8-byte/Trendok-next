import './globals.css'
import React from 'react'
import Header from '../components/Header'

export const metadata = {
  title: 'TRENDOK',
  description: 'Fashion. Lifestyle. Tendințe care inspiră.',
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="ro">
      <body>
        <Header />
        <main className="container" style={{paddingTop:20}}>
          {children}
        </main>
        <footer className="footer">© 2025 TRENDOK — Toate drepturile rezervate.</footer>
      </body>
    </html>
  )
}
