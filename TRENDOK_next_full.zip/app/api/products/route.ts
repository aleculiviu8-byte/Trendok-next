import { NextResponse } from 'next/server'

const products = Array.from({length:12}).map((_,i)=>({
  id: i+1,
  title: `Rochie elegantă ${i+1}`,
  brand: i % 2 === 0 ? 'Brand A' : 'Brand B',
  price: (49 + i*5).toFixed(2),
  oldPrice: (99 + i*5).toFixed(2),
  image: `https://picsum.photos/seed/tr${i}/800/1000`,
  description: 'Descriere scurtă produs. Material confortabil, croială modernă.'
}))

export function GET(){
  return NextResponse.json(products)
}
