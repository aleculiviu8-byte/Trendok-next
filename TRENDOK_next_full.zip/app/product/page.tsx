import React from 'react'

async function getProduct(id:string){
  const res = await fetch(`${process.env.NEXT_PUBLIC_SITE_URL || ''}/api/products`);
  const products = await res.json();
  return products.find((p:any)=>String(p.id)===String(id));
}

export default async function ProductPage({ params }: { params: { id: string } }) {
  const product = await getProduct(params.id);
  if(!product) return <div>Produsul nu există</div>
  return (
    <div style={{display:'flex',gap:24,marginTop:20}}>
      <div style={{flex:'1 1 60%'}}>
        <div style={{height:480,backgroundImage:`url(${product.image})`,backgroundSize:'cover',borderRadius:12}}></div>
      </div>
      <div style={{flex:'1 1 40%'}}>
        <h1>{product.title}</h1>
        <p style={{color:'#6b7280'}}>{product.brand}</p>
        <div style={{marginTop:12}}>
          <div className="price">{product.price} lei</div>
          <div className="price-old">{product.oldPrice} lei</div>
        </div>
        <p style={{marginTop:12}}>{product.description}</p>
        <div style={{marginTop:18}}>
          <button className="btn">Adaugă în coș</button>
        </div>
      </div>
    </div>
  )
}
