TRENDOK — Frontpage Enhanced
Files:
- index.html : single-file frontpage using Tailwind CDN + minimal JS
How to use:
- Open index.html in a browser. No build step required.
- Replace image URLs with your own assets.
- Optionally convert to React/Next.js or Vite for advanced use.
